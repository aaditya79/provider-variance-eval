# Canonical result files (provider-variance study)

Raw per-call JSONL logs — the source of truth for every table in the paper (see
PREREGISTRATION.md §35). Archived here because `~/pv_runs/` is gitignored.

## Layout
- `<cell>/<benchmark>.jsonl` — one JSON object per API call (raw completion, read-back,
  tokens, cost, grade, invalid_reason/subtype, timestamps).
- `<cell>/manifest_*.json`, `provenance.json`, `resolved.yaml`, `config.snapshot.yaml` —
  run provenance (git sha, UTC timestamps, resolved config, persisted row/byte counts).
- `humaneval_llama-3.3-70b_recovered/_lineage/` — base-run provenance + the novita
  recovery patch that was merged to form the canonical recovered file (PREREGISTRATION §32-33).
- `provider_snapshots/` — provider/quant snapshot JSON.
- `MANIFEST.md` — per-cell rows/bytes/sha256.  `CHECKSUMS.sha256` — all files.

## Verify integrity
    shasum -a 256 -c CHECKSUMS.sha256
